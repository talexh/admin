<?php

return array(

	"home"     => "Početna",
	"about"    => "O nama",
	"blog"     => "Blog",
	"contact"  => "Kontakt",
	"channels" => "Sadržaj",

);
