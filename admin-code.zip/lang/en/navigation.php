<?php

return array(

	"home"     => "Home",
	"about"    => "About",
	"blog"     => "Blog",
	"contact"  => "Contact",
	"channels" => "Channels",

);
