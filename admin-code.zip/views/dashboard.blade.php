@extends('admin::_layout.admin')

@section('leftnav')
@include('admin::_partial._leftnav')
@stop

@section('main')
<h1 class="page-header">Dashboard</h1>
<h3>Welcome to dashboard page</h3>
@stop