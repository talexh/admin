@extends('admin::_layout.default')

@section('main')
	<div class="col-lg-123">
		<h2>Not found</h2>
		<p>404 Error</p>
	</div>
@stop
