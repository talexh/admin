<ul class="toolbar-nav">
	<li><a href="/admin/{{$ctrl}}" class="btn cancel" title="{{Lang::get('admin::common.cancel')}}"><i class="glyphicon glyphicon-remove"></i></a></li>
	<li><a href="javascript:;" title="{{Lang::get('admin::common.saved-stay')}}" class="btn saveopen"><i class="glyphicon glyphicon-floppy-saved"></i></a></li>
	<li><a href="javascript:;" title="{{Lang::get('admin::common.saved-add')}}" class="btn saveaddnew"><i class="glyphicon glyphicon-floppy-open"></i></a></li>
	<li><a href="javascript:;" title="{{Lang::get('admin::common.saved-close')}}" class="btn saveclose"><i class="glyphicon glyphicon-floppy-remove"></i></a></li>
	<li><a href="/admin/{{$ctrl}}/add" class="btn add"><i class="glyphicon glyphicon-plus"></i></a></li>
</ul>
