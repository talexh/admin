<ul class="toolbar-nav">
	<li><a href="/admin/{{$ctrl}}/add" class="btn add"><i class="glyphicon glyphicon-plus"></i></a></li>
	<li><a href="javascript:;" class="btn del"><i class="glyphicon glyphicon-trash"></i></a></li>
</ul>