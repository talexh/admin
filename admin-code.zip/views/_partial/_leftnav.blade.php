
<div class="col-sm-3 col-md-2 sidebar">

	<ul class="nav nav-sidebar">
		<li class="{{{ (($ctrl=='apps') ?'active':'') }}}">
			<a href="/admin/apps">Apps Management</a>
		</li>
		<li class="{{{ (($ctrl=='category') ?'active':'') }}}">
			<a href="/admin/category">Categories Management</a>
		</li>
		<li class="{{{ (($ctrl=='news') ?'active':'') }}}">
			<a href="/admin/news/list">Contents Management</a>
		</li>
	</ul>

</div>
